---
title: CodeReviewer AI
emoji: 🐨
colorFrom: blue
colorTo: red
sdk: streamlit
sdk_version: 1.42.0
app_file: app.py
pinned: false
license: apache-2.0
short_description: A smart, multi-agent code review system powered by LLMs (Groq/OpenAI) that performs comprehensive code analysis.
---

### End To End Agentic AI Projects

The project is in development